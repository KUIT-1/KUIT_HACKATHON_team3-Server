package com.example.kuitbucksServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KuitbucksServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KuitbucksServerApplication.class, args);
	}

}
