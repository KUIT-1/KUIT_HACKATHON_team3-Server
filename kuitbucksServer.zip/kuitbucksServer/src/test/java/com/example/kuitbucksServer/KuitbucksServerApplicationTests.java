package com.example.kuitbucksServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KuitbucksServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
